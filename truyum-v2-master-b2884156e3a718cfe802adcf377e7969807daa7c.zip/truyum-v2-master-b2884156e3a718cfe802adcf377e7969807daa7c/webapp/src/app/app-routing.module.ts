import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {CartComponent} from '../app/shopping/cart/cart.component';
import {SearchComponent} from 'src/app/food/search/search.component';
import {ItemEditComponent} from 'src/app/food/item-edit/item-edit.component';
import {ItemInfoComponent} from 'src/app/food/item-info/item-info.component';
import {LoginComponent} from './site/login/login.component';
import {SignupComponent} from './site/signup/signup.component';
import {AuthGuard} from './site/auth/auth.guard';
const routes: Routes = [
  {path : 'cart' ,component : CartComponent, canActivate:[AuthGuard]},
  {path : 'menu', component : SearchComponent},
  {path: 'admin' ,component : ItemInfoComponent},
  {path: 'edit/:id', component : ItemEditComponent,canActivate: [AuthGuard]},
  {path: 'login', component : LoginComponent},
  {path: 'signup', component : SignupComponent},
  {path: '', redirectTo: 'menu', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
