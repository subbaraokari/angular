export interface Iuser {
    username: string;
    password: string;
    confirmPassword : string;
    firstname:string;
    lastname:string;
    role: string;
}