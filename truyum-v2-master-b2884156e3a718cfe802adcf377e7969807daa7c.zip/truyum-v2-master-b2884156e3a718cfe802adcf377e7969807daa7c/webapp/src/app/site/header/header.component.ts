import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CartserviceService } from 'src/app/shopping/cartservice.service';
import { AuthserviceService } from '../authservice.service';
import { AuthenticationServiceService } from '../login/authentication-service.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router: ActivatedRoute,private route: Router, private cartService:CartserviceService, private authService:AuthserviceService, private authenticationService: AuthenticationServiceService) { }

  
  isAuthenticated() {
    return this.authService.loggedIn;
  }
  getUser() {
    return this.authService.userAuthenticated;
  }
  isAdmin() {
    return this.authService.isAdmin;
  }
  isCustomer() {
    return this.authService.isCustomer;
  }
  getUserName() {
    //return this.authService.userAuthenticated.username;
    return this.authService.username;
  }
  onSignOut() {
    this.authService.logout();
    this.route.navigate([this.authService.redirectUrlLogin]);
  }

  
  ngOnInit() {
  }

}
