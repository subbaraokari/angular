import { Component, OnInit } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { Route, Router, ActivatedRoute } from '@angular/router';
import { AuthenticationServiceService } from './authentication-service.service';
import { AuthserviceService } from '../authservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
authentication: Boolean = false;
isLoginValid = true;
authSource:string;
loginForm:FormGroup;
username:string = "";
password:string = "";
userValid: boolean = true;
  constructor(private router :Router, private route:ActivatedRoute, private authenticationService: AuthenticationServiceService, private authService:AuthserviceService) { 
  }

  error: String = '';

  ngOnInit() {
    //this.authSource = this.authService.authSource;
    if(this.authenticationService.getId() != null && this.authService.authSource == 'cart') {
      this.error = "Please login before adding an item to Cart";
    }
  }
  // onSubmit(form:NgForm) {
  //   this.username = form.value.username;
  //   this.password = form.value.password;
  //   this.authentication = this.authService.logIn(this.username,this.password);
  //   if(this.authentication) {
  //     this.router.navigate([this.authService.redirectUrl]);
  //     this.userValid = true;
  //   }
  //   else {
  //     this.userValid = false;
  //   }
  // }

  
  onSubmit() {
    // console.log(this.username);
    // console.log(this.password);
    let authResult = this.authenticationService.authenticate(this.username, this.password);
    authResult.subscribe(
      data => {
        console.log("Authentication success !!! Token : " + this.authenticationService.getToken());
        this.authenticationService.setToken(data.token);

        const foodId = +this.route.snapshot.paramMap.get("id");
        this.authenticationService.setToken(data.token);
        this.authenticationService.setRole(data.role);
        //this.authenticationService.setUserName(this.username);
        this.authenticationService.setUserId(data.id);
        const authenticated = this.authService.login(data.role, this.username);
        this.router.navigate(['menu']);
      },
      err => {
        console.log("Error in authentication : " + JSON.stringify(err));
        if(err.status == 401) {
          this.error = "Invalid username and/or password";
        }
      }
    );
  }
}
