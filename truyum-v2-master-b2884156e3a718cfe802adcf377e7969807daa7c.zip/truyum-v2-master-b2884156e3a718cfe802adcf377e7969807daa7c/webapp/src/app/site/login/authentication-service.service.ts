import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { AuthserviceService } from '../authservice.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService {

  private authenticationApiUrl = environment.baseUrl+'/authenticate';
  public token: string;
  id: number;
  role: string;
  username: string;
  
  constructor(private httpClient: HttpClient) { }

  authenticate(user: string, password: string): Observable<any> {
    let credentials = btoa(user + ':' + password);
    let headers = new HttpHeaders();
    headers = headers.set('Authorization', 'Basic ' + credentials);
    //console.log("inside authenticate fun()"+credentials);
    return this.httpClient.get(this.authenticationApiUrl, {headers});
  }

  // logout() {
  //   this.authService.redirectUrl = '/';
  //   this.authService.loggedIn = false;
  //   this.authService.isCustomer = false;
  //   this.authService.isAdmin = false;
  //   this.userId = null;
  //   this.role = null;
  // }

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }

  setId(foodId: number) {
    this.id = foodId;
  }
  getId() : number {
    return this.id;
  }

  setRole(_role:string) {
    this.role = _role;
  }
  getRole() {
    return this.role;
  }

  // setUserId(id:number) {
  //   this.userId = id;
  // }

  // getUserId(): number{
  //   return this.userId;
  // }
  
  // public setUserName(name: string) {
  //   this.username = name;
  // }

  // public getUserName() {
  //   return this.username;
  // }

  userId;number;
  public setUserId(id:string) {
    this.userId = id;
  }

  public getUserId() {
    return this.userId;
  }
}
