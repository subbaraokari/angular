import { Injectable } from '@angular/core';
import { Iuser } from './user';
import { isBuffer } from 'util';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { AuthenticationServiceService } from './login/authentication-service.service';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  user:Iuser;
  userList:Iuser[];
  // userList:Iuser[] = [
  //   {"username" : "john", "password" : "john123", "firstname" : "john", "lastname" : "abc", "role" : "customer"},
  //   {"username" : "mary", "password" : "mary123", "firstname" : "mary", "lastname" : "abc", "role" : "customer"},
  //   {"username" : "david", "password" : "david123", "firstname" : "david", "lastname" : "abc", "role" : "admin"}    
  // ]
  constructor(private httpClient: HttpClient, private authenticationService: AuthenticationServiceService) { }
  authenticate(username: string, password: string) {
    this.userList.forEach(element => { 
      if(username == element.username && password == element.password) {
        this.user = element;
      }
    });
    return this.user;
  }
  getUser() : Iuser[] {
    return this.userList;
  }
  // addUserCustomer(user:Iuser) {
  //   this.userList.push(user);
  //   console.log(this.userList);
  // }

  public addUser(user: Iuser): Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    return this.httpClient.post<void>(environment.baseUrl+"/user", user, httpOptions);
  }

}
