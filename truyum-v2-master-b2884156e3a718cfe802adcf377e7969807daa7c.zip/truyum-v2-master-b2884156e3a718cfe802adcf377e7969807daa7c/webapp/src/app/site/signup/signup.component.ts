import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { UserserviceService } from '../userservice.service';
import {Router } from '@angular/router';
import { Iuser } from '../user';
import { AuthserviceService } from '../authservice.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm:FormGroup;
  //signedUp:boolean = false;
  user: Iuser = {
    "firstname" : "",
    "lastname" : "",
    "username" : "",
    "password" : "",
    "confirmPassword" : "",
    "role" : ""
  };
  constructor(public userService:UserserviceService, public authService : AuthserviceService, private router: Router) { }

 
  ngOnInit() {
    this.signupForm = new FormGroup({
      'username' : new FormControl(this.user.username),
      'firstname' : new FormControl(this.user.firstname),
      'lastname' : new FormControl(this.user.lastname),
      'password' : new FormControl(this.user.password),
      'cpassword' : new FormControl(this.user.confirmPassword)
    });
    
  }
  // onSubmitSignUp() {    
  //   if( this.signupForm.value.password == this.signupForm.value.cpassword) {
  //     this.user.firstname = this.signupForm.value.firstname;
  //     this.user.lastname = this.signupForm.value.lastname;
  //     this.user.password = this.signupForm.value.password;
  //     this.user.username = this.signupForm.value.username;
  //     this.user.role = "customer";
  //     this.userService.addUserCustomer(this.user);
  //     console.log(this.user);
  //     this.signedUp = true;
  //     this.router.navigate([this.authService.redirectUrlLogin]);
  //   }
  // }

  error:string;
  passwordMismatch:string;
  pwdLength : boolean = false;
  userExists : boolean = false;
  addUser() {
    if( this.signupForm.value.password == this.signupForm.value.cpassword) {
      this.user.firstname = this.signupForm.value.firstname;
      this.user.lastname = this.signupForm.value.lastname;
      this.user.password = this.signupForm.value.password;
      this.user.confirmPassword = this.signupForm.value.cpassword;
      this.user.username = this.signupForm.value.username;
      console.log(this.user);
      this.userService.addUser(this.user).subscribe(() => this.router.navigate([this.authService.redirectUrlLogin]),
      err => {
        if(err.message == "User already exists") {
          this.pwdLength = true;
          this.error = "Password length: min = 2, max = 10";
        }
        else {
          this.error = err.error.message;
          this.userExists = true;
          //this.error = "User already exists"
        }
      });
      //this.signedUp = true;
    }
    else {
      this.passwordMismatch = "Password and Confirm Password did not match."
    }
  }
}
