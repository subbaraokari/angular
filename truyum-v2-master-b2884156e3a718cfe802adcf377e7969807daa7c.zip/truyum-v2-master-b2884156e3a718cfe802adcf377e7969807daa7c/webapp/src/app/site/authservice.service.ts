import { Injectable } from '@angular/core';
import { Iuser } from './user';
import { UserserviceService } from './userservice.service';
import { AuthenticationServiceService } from './login/authentication-service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthserviceService {
  loggedIn = false;
  isAdmin = false;
  isCustomer = false;
  user: Iuser;
  redirectUrl :string  = '/menu';
  redirectUrlLogin = '/login';
  userAuthenticated : Iuser;
  authSource: string = null;

  role: string;
  username:string;

  constructor(private userService: UserserviceService, private authenticationService: AuthenticationServiceService) { }

  // logIn(username:string, password: string) : Boolean {

  //   this.user = this.userService.authenticate(username,password);

  //   console.log(this.user); 

    // if(this.user != null && this.user.role == 'admin') {
    //   this.loggedIn = true;
    //   this.userAuthenticated = this.user;
    //   this.isAdmin = true;
    //   this.isCustomer = false;
    //   //this.redirectUrl =  '/admin';
    //   return true;
    // }
    // else if(this.user != null && this.user.role == 'customer') {
    //   this.loggedIn = true;
    //   this.userAuthenticated = this.user;
    //   this.isAdmin = false;
    //   this.isCustomer = true;
    //   //this.redirectUrl = '/menu';
    //   return true;
    // } 
    // else {
    //   this.isCustomer = false;
    //   this.isAdmin = false;
    //   //this.redirectUrl = '/login';
    // }
  // }

  login(role : string, username:string) : Boolean {

    this.username = username;
    if(role == "USER") {
      this.loggedIn = true;
      this.userAuthenticated = this.user;
      this.isAdmin = false;
      this.isCustomer = true;
      return true;
    } else if(role == "ADMIN") {
      this.loggedIn = true;
      this.userAuthenticated = this.user;
      this.isAdmin = true;
      this.isCustomer = false;
      return true;
    } else {
      this.isCustomer = false;
      this.isAdmin = false;
    }
  }
  logout() {
    this.redirectUrl = '/';
    this.loggedIn = false;
    this.isCustomer = false;
    this.isAdmin = false;
    this.authenticationService.setRole(null);
    this.authenticationService.setToken(null);
  }  
}
