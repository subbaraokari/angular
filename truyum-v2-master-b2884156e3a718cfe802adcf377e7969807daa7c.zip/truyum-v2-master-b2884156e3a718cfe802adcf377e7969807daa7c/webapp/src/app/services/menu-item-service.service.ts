import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthserviceService } from '../site/authservice.service';
import { Observable } from 'rxjs';
import { IfoodItem } from '../food/Ifood-item';
import { AuthenticationServiceService } from '../site/login/authentication-service.service';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class MenuItemServiceService {

  public menuItemList : IfoodItem[];
  public menuItem : IfoodItem;
  

  constructor(private httpClient: HttpClient, private authService: AuthserviceService, private authenticationService : AuthenticationServiceService ) { 
    //this.getMenuItems().subscribe(data => console.log(data), err => console.log(err));
  }

  private token : string = this.authenticationService.getToken();

  private menuItemApiUrl = environment.baseUrl + '/menu-items';

  public getMenuItems(): Observable<any> {
    //console.log("inside getallMenuItems()");
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    return this.httpClient.get(this.menuItemApiUrl, httpOptions);
  }

  //private menuItemByIdApiUrl = environment.baseUrl + '/menu-items/{id}';

  public getMenuItemById(id: number): Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    return this.httpClient.get(this.menuItemApiUrl+"/"+id, httpOptions);
  }

  public save(menuItem : IfoodItem) : Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    return this.httpClient.put<void>(this.menuItemApiUrl , menuItem, httpOptions);
  }

  

}
