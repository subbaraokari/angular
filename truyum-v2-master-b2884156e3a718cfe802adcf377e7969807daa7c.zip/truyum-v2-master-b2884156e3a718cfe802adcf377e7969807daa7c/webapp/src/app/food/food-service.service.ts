import { Injectable } from '@angular/core';
import { IfoodItem } from './Ifood-item';
import { forEach } from '@angular/router/src/utils/collection';
import { AuthserviceService } from '../site/authservice.service';
import { MenuItemServiceService } from '../services/menu-item-service.service';

@Injectable({
  providedIn: 'root'
})
export class FoodServiceService {

  menuItemlist : IfoodItem[] = [
    {
      "id" : 1,
      "name" : "Sandwich",
      "price" : 99,
      "active" : true,
      "dateOfLaunch" : new Date('03/15/2017'),
      "category" : "Main Course",
      "freeDelivery" : true,
      "url" : "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
    },
    {
      "id" : 2,
      "name" : "Burger",
      "price" : 129,
      "active" : true,
      "dateOfLaunch" : new Date('12/23/2017'),
      "category" : "Main Course",
      "freeDelivery" :false,
      "url" : "https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
    },
    {
      "id" : 3,
      "name" : "Pizza",
      "price" : 149,
      "active" : true,
      "dateOfLaunch" : new Date('08/21/2017'),
      "category" : "Main Course",
      "freeDelivery" : false,
      "url" : "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
    },
    {
      "id" : 4,
      "name" : "French Fries",
      "price" : 57,
      "active" : false,
      "dateOfLaunch" : new Date('07/02/2017'),
      "category" : "Starters",
      "freeDelivery" : true,
      "url" : "https://images.unsplash.com/photo-1526230427044-d092040d48dc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
    },
    {
      "id" : 5,
      "name" : "Chocolate Brownie",
      "price" : 32,
      "active" : true,
      "dateOfLaunch" : new Date('11/02/2022'),
      "category" : "Dessert",
      "freeDelivery" : true,
      "url" : "https://images.unsplash.com/photo-1564355808539-22fda35bed7e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
    }
  ];
  getAllItems() : IfoodItem[] {
    return this.menuItemlist;
  }
  foodFilt : IfoodItem[];
  getFoodItems( _active:boolean, _launchDate : Date ): IfoodItem[] {
    this.foodFilt = this.menuItemlist.filter(x=>x.active == _active && x.dateOfLaunch < _launchDate);
    return this.foodFilt;
  }
  searchKey:string;
  search(searchKey : string): IfoodItem[] {
    this.menuItemService.getMenuItems().subscribe(data => this.menuItemlist = data);
    // if(this.authService.isAdmin)
    // this.foodFilt = this.menuItemlist.filter(x=>x.name.toLowerCase().indexOf(searchKey.toLowerCase())!==-1);
    // else
    // {
      this.foodFilt = this.menuItemlist.filter(x=>x.name.toLowerCase().indexOf(searchKey.toLowerCase())!==-1);
    //}
    //this.foodFilt = this.menuItemlist.filter(x=>x.name.toLowerCase().indexOf(searchKey.toLowerCase())!==-1 && x.active == true && x.dateOfLaunch < new Date());
    
    return this.foodFilt;
  }
  item:IfoodItem;
  // getFoodItemById(index:number) : IfoodItem {
  //   this.menuItemlist.forEach(element => {
  //     if(element.id == index) 
  //     this.item = element;
  //   });
  //   return this.item;
  // }

  getFoodItemById(index:number) : IfoodItem {
    this.menuItemlist.forEach(element => {
      if(element.id == index) 
      this.item = element;
    });
    return this.item;
  }

  getFoodItemsAdmin(): IfoodItem[] {
    return this.menuItemlist;
  }
  UpdateFoodItem(item:IfoodItem) {
    const index = this.menuItemlist.findIndex(x=>x.id == item.id);
    this.menuItemlist[index] = item;
  }
  constructor(private authService:AuthserviceService, private menuItemService: MenuItemServiceService) {}
}
