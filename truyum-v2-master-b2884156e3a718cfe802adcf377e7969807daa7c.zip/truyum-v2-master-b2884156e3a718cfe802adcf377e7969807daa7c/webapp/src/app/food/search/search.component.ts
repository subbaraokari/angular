import { Component, OnInit } from '@angular/core';
import { IfoodItem } from '../Ifood-item';
import { FoodServiceService } from '../food-service.service';
import { MenuItemServiceService } from 'src/app/services/menu-item-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchKey: string;
  searchedItems : IfoodItem[]=[];
  menuItemList : IfoodItem[];
  search() {
    //this.searchedItems = this.foodService.search(this.searchKey);

    this.menuItemService.getMenuItems().subscribe(data => 
      {
        this.menuItemList = data,
        this.searchedItems = this.menuItemList.filter(x=>x.name.toLowerCase().indexOf(this.searchKey.toLowerCase())!==-1);
      });

  }
  constructor(public foodService : FoodServiceService, public menuItemService: MenuItemServiceService) { }

  ngOnInit() {
  }

}
