import { Component, OnInit, Input, Output } from '@angular/core';
import { IfoodItem } from '../Ifood-item';
import { FoodServiceService } from '../food-service.service';
import { Icart } from 'src/app/shopping/cart/Icart';
import { EventEmitter } from '@angular/core';
import { CartserviceService } from 'src/app/shopping/cartservice.service';
import { AuthserviceService } from 'src/app/site/authservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MenuItemServiceService } from 'src/app/services/menu-item-service.service';
import { AuthenticationServiceService } from 'src/app/site/login/authentication-service.service';

@Component({
  selector: 'app-item-info',
  templateUrl: './item-info.component.html',
  styleUrls: ['./item-info.component.css']
})
export class ItemInfoComponent implements OnInit {
  @Input() menuItemList : IfoodItem[];
  @Output() addedToCart = new EventEmitter();
  isAdmin: boolean = true;
  isCustomer: boolean = this.authService.isCustomer;
  
  itemAdded = false;
  itemId : number;
  role:string;
  //userName: string;

  constructor(private foodService: FoodServiceService, private cartService:CartserviceService, private authService:AuthserviceService,private router: ActivatedRoute, private route: Router, private menuItemService : MenuItemServiceService, private authenticationService: AuthenticationServiceService) { }

  ngOnInit() {
    //this.menuItemList = this.foodService.getAllItems();
    this.role = this.authenticationService.getRole();
    // if(this.isEditAllowed()){
    //   this.menuItemList = this.foodService.getFoodItemsAdmin();
    // }
    // else {
    //   //this.menuItemList = this.foodService.getFoodItems(true,new Date());
    //   this.menuItemService.getMenuItems().subscribe(data => this.menuItemList = data);
    // }
    this.menuItemService.getMenuItems().subscribe(data => this.menuItemList = data);
    // if(this.role == "ROLE_USER") {
    //   this.menuItemService.getMenuItems().subscribe(data => this.menuItemList = data);
    //   //console.log(this.menuItemList);
    // } 
    // else if(this.role == "ROLE_ADMIN") {
    //   this.menuItemService.getMenuItems().subscribe(data => this.menuItemList = data);
    // }

    
  }
  isEditAllowed() : Boolean{
    return this.authService.isAdmin;
  }

    // addToCart(id : number) {
    //   if(this.isCustomer) {
    //     this.itemName = this.cartService.addToCart(id);
    //     this.addedToCart.emit(id);
    //     this.itemAdded = true;
    //     setTimeout(() => {
    //       this.itemAdded = false;
    //     }, 1000);
    //     return false;
    //   }
    //   else 
    //   {
    //     this.authService.authSource='cart';
    //     const foodId = +this.router.snapshot.paramMap.get("id");
    //     this.authenticationService.setId(foodId);
    //     this.route.navigate([this.authService.redirectUrlLogin]);
    //   }  
    // }

    userId:number;
    
    AddToCartClick(menuItemId : number) {
      if(this.isCustomer) {
        //this.userName = this.authenticationService.getUserName()
        this.userId = this.authenticationService.getUserId();
        //this.itemName = this.cartService.getItemName(menuItemId);
        this.itemId = menuItemId;
        this.addedToCart.emit(menuItemId);
        this.itemAdded = true;
        setTimeout(() => {
          this.itemAdded = false;
        }, 1000);
        this.cartService.addCartItem(this.userId, menuItemId).subscribe();
        return false;
      }
      else 
      {
        this.authService.authSource='cart';
        const foodId = +this.router.snapshot.paramMap.get("id");
        this.authenticationService.setId(foodId);
        this.route.navigate([this.authService.redirectUrlLogin]);
      }  
    }
    // onSubmit() {
    //   if(this.authService.loggedIn == false) {

    //     this.router.navigate([this.authService.redirectUrlLogin]);
    //   }
    // }

    onEditClick(id: number) {
      this.route.navigate(['/edit',id]);
      //this.route.navigateByUrl('/edit');
    }
  }