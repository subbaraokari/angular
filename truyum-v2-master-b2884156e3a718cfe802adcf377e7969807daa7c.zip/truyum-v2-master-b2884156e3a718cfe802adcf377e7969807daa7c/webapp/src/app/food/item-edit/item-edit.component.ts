import { Component, OnInit } from '@angular/core';
import { IfoodItem } from '../Ifood-item';
import { ActivatedRoute } from '@angular/router';
import { FoodServiceService } from '../food-service.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MenuItemServiceService } from 'src/app/services/menu-item-service.service';

@Component({
  selector: 'app-item-edit',
  templateUrl: './item-edit.component.html',
  styleUrls: ['./item-edit.component.css']
})
export class ItemEditComponent implements OnInit {
  item:IfoodItem;
  id:number;
  menuItemlist: IfoodItem[] = this.foodService.getFoodItemsAdmin();
  editForm: FormGroup;
  constructor(private route:ActivatedRoute, private foodService: FoodServiceService, private menuItemService: MenuItemServiceService) { }
  foodEdited: boolean ;
  ngOnInit() {
    // const foodId =+ (this.route.snapshot.paramMap.get('id'));
    // this.item = this.foodService.getFoodItemById(foodId);
    // this.id = foodId;
    // this.editForm = new FormGroup({
    //   'name': new FormControl(this.item.name,[Validators.required,Validators.maxLength(200)]),
    //   'price' : new FormControl(this.item.price,[Validators.required,Validators.pattern('^[0-9]+$')]),
    //   'category' : new FormControl(this.item.category,[Validators.required]),
    //   'dateOfLaunch' : new FormControl(this.item.dateOfLaunch),
    //   'active' : new FormControl(this.item.active,[Validators.required]),
    //   'freeDelivery' : new FormControl(this.item.freeDelivery)
    // })
    // this.foodEdited = false;

    const foodId =+ (this.route.snapshot.paramMap.get('id'));
    this.menuItemService.getMenuItemById(foodId).subscribe(data => {this.item = data
    this.id = foodId;
    //console.log(this.item);
    this.editForm = new FormGroup({
      'name': new FormControl(this.item.name,[Validators.required,Validators.maxLength(200)]),
      'price' : new FormControl(this.item.price,[Validators.required,Validators.pattern('^[0-9]+$')]),
      'category' : new FormControl(this.item.category,[Validators.required]),
      'dateOfLaunch' : new FormControl(this.item.dateOfLaunch),
      'active' : new FormControl(this.item.active,[Validators.required]),
      'freeDelivery' : new FormControl(this.item.freeDelivery)
    }); })
    this.foodEdited = false;
  }
  
  // UpdateFoodItem() : void {
  //   this.item.name = this.editForm.value.name;
  //   this.item.price = this.editForm.value.price;
  //   this.item.category = this.editForm.value.category;
  //   this.item.dateOfLaunch = this.editForm.value.dateOfLaunch;
  //   this.item.active = this.editForm.value.active;
  //   this.item.freeDelivery = this.editForm.value.freeDelivery;
  //   this.foodService.UpdateFoodItem(this.item);
  //   this.foodEdited = true;
  // }

  UpdateFoodItem() : void {
      this.item.name = this.editForm.value.name;
      this.item.price = this.editForm.value.price;
      this.item.category = this.editForm.value.category;
      this.item.dateOfLaunch = this.editForm.value.dateOfLaunch;
      this.item.active = this.editForm.value.active;
      this.item.freeDelivery = this.editForm.value.freeDelivery;
      this.menuItemService.save(this.item).subscribe();
    console.log(this.item);
    this.foodEdited = true;
  }
  get name() { return this.editForm.get('name'); }
  get price() { return this.editForm.get('price'); }
  get category() { return this.editForm.get('category'); }
  }
