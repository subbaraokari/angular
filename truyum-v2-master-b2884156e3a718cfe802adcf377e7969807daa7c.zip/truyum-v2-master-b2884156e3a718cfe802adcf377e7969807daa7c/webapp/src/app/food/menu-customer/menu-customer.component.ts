import { Component, OnInit, Input} from '@angular/core';
import { FoodServiceService } from '../food-service.service';
import { IfoodItem } from '../Ifood-item';
import {CartserviceService} from 'src/app/shopping/cartservice.service';

@Component({
  selector: 'app-menu-customer',
  templateUrl: './menu-customer.component.html',
  styleUrls: ['./menu-customer.component.css']
})
export class MenuComponent implements OnInit {
  @Input()
  menuItemList: IfoodItem[] = [];
  addToCart(cartItem : IfoodItem) {
    //this.cartService.addToCart(cartItem.id);
  }


  searchKey: string;
  searchedItems : IfoodItem[]=[];
  search() {
    this.searchedItems = this.foodService.search(this.searchKey);
  }
  
  constructor(public cartService : CartserviceService, public foodService : FoodServiceService) { }

  ngOnInit() {
    this.menuItemList = this.foodService.getFoodItems(true,new Date());
  }

}
