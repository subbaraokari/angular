import { Injectable } from '@angular/core';
import { Icart } from './cart/Icart';
import { IfoodItem } from '../food/Ifood-item';
import { FoodServiceService } from '../food/food-service.service';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { AuthenticationServiceService } from '../site/login/authentication-service.service';
import { environment } from 'src/environments/environment';
import { AuthserviceService } from '../site/authservice.service';

@Injectable({
  providedIn: 'root'
})
export class CartserviceService {
  total:number;
  cart : Icart = {
    cartItems : [
      // {
      //   "id" : 1,
      //   "name" : "Sandwich",
      //   "price" : 99,
      //   "active" : true,
      //   "dateOfLaunch" : new Date('03/15/2017'),
      //   "category" : "Main-course",
      //   "freeDelivery" : true,
      //   "url" : "https://images.unsplash.com/photo-1528735602780-2552fd46c7af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
      // },
      // {
      //   "id" : 2,
      //   "name" : "Burger",
      //   "price" : 129,
      //   "active" : true,
      //   "dateOfLaunch" : new Date('12/23/2017'),
      //   "category" : "Main-course",
      //   "freeDelivery" :false,
      //   "url" : "https://images.unsplash.com/photo-1512152272829-e3139592d56f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
      // },
      // {
      //   "id" : 3,
      //   "name" : "Pizza",
      //   "price" : 149,
      //   "active" : true,
      //   "dateOfLaunch" : new Date('08/21/2017'),
      //   "category" : "Main-course",
      //   "freeDelivery" : false,
      //   "url" : "https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60"
      // }
    ],
    total:0
  }
  cartItem: IfoodItem;
  // getCart() : Icart {
  //   this.cart.total = this.totalPriceCalculate();
  //   return this.cart;
  // }
  // totalPriceCalculate():number {
  //   this.total = 0;
  //   for(let item of this.cart.cartItems) {
  //     this.total += item.price;
  //   }
  //   return this.total;
  // }
  // getItemName(id:number) {
  //   this.cartItem = this.foodService.getFoodItemById(id);
  //   this.cart.cartItems.push(this.cartItem);
  //   return this.cartItem.name;
  // }
  // deleteCart(index:number) {
  //   const item_index = this.cart.cartItems.findIndex(item => item.id == index);
  //   this.cart.cartItems.splice(item_index,1);
  //   this.getCart();
  // }
  constructor(private foodService: FoodServiceService, private authenticationService: AuthenticationServiceService, private httpClient: HttpClient, private authService: AuthserviceService) { }


  public addCartItem(userId: number, menuItemId : number) : Observable<void> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    return this.httpClient.post<void>(environment.baseUrl+"/carts/" + userId + "/" + menuItemId,menuItemId, httpOptions);
  }

  public getAllCartItems() : Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    //const userName = this.authenticationService.getUserName();
    const userId = this.authenticationService.getUserId();
    return this.httpClient.get(environment.baseUrl +"/carts/" + userId, httpOptions);
  }

  public deleteCartItem(userName : string,menuItemId : number) : Observable<any> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization' : 'Bearer '+this.authenticationService.getToken()
      })
    };
    return this.httpClient.delete(environment.baseUrl+"/carts/" + userName + "/" + menuItemId, httpOptions);
  }
}
