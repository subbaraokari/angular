import { Component, OnInit } from '@angular/core';
import { CartserviceService } from '../cartservice.service';
import { Icart } from './Icart';
import { AuthserviceService } from 'src/app/site/authservice.service';
import { AuthenticationServiceService } from 'src/app/site/login/authentication-service.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart :Icart;
  total:number;
  
  deleted:boolean = false;
  constructor(public cartService : CartserviceService, private authService:AuthserviceService, private authenticationService: AuthenticationServiceService) { }
  // getCart() {
  //   this.cartService.getCart();
  // }
  // totalPriceCalculate()  {
  //   return this.cartService.totalPriceCalculate();
  // }
  // deleteCart(index:number) {
  //   this.cartService.deleteCart(index);
  // }

  onDeleteClick(menuItemId: number) {
    //const userName = this.authenticationService.getUserName();
    const userId = this.authenticationService.getUserId();
    this.cartService.deleteCartItem(userId, menuItemId).subscribe(() => {
      this.reDirect();
      this.deleted = true;
    },
    err => {
      this.cartException = true;
    });
  }

  reDirect() {
    this.cartService.getAllCartItems().subscribe(data => {
      this.cart = data,
      this.cartException = false;
    },
    err => {
      this.cartException = true;
    })
  }
  cartException : boolean;
  cartEmptyMsg: string;
  ngOnInit() {
    this.deleted = false;
    this.cartService.getAllCartItems().subscribe(data => 
    {
      this.cart = data,
      this.total = data.total;
    },
    err => 
    {
      this.cartEmptyMsg = err.error.message,
      this.cartException = true;
    }
    );
  }

}
