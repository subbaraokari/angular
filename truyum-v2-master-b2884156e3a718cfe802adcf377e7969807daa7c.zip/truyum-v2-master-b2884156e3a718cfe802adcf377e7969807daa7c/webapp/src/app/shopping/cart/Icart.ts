import { IfoodItem } from "src/app/food/Ifood-item";

export interface Icart {
    cartItems : IfoodItem[];
    total: number;
}