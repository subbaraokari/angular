package com.cognizant.truyum.exception;

@SuppressWarnings("serial")
public class CartEmptyException extends Exception {

	public String getMessage() {
		return "Cart empty Exception !!!";
	}
}
