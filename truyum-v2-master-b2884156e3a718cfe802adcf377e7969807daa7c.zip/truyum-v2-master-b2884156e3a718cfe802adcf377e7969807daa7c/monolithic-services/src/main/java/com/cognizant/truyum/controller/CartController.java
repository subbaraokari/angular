package com.cognizant.truyum.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.dto.CartDTO;
import com.cognizant.truyum.exception.CartEmptyException;
import com.cognizant.truyum.service.CartService;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/carts")
public class CartController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartController.class);
			
	@Autowired
	CartService cartService;
	
	@PostMapping("/{userId}/{menuItemId}")
	public void addCartItem(@PathVariable int userId, @PathVariable long menuItemId) {
		
		LOGGER.info("addCartItem Controller...");
		
		this.cartService.addCartItem(userId, menuItemId);
	}
	
	@GetMapping("/{userId}")
	public CartDTO getAllCartItems(@PathVariable int userId) throws CartEmptyException {
		
		LOGGER.info("getAllCartItems Controller...");
		
		return this.cartService.getAllCartItems(userId);
	}
	
	@DeleteMapping("/{userId}/{menuItemId}")
	public void removeCartItem(@PathVariable int userId,@PathVariable long menuItemId) {
		
		LOGGER.info("removeCartItem Controller...");
		
		this.cartService.removeCartItem(userId, menuItemId);
	}
}
