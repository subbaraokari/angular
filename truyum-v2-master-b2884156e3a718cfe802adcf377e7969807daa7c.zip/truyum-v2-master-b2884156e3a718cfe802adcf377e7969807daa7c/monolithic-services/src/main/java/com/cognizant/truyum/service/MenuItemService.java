package com.cognizant.truyum.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.repository.MenuItemRepository;

@Service
public class MenuItemService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemService.class);
	
	@Autowired
	private MenuItemRepository menuItemRepository;

	@Transactional
	public List<MenuItem> getMenuItemListCustomer() {
		
		LOGGER.info("getMenuItemListCustomer Service");
		return menuItemRepository.getMenuItemsCustomer();
	}
	
	@Transactional
	public List<MenuItem> getMenuItemListAdmin() {
		
		LOGGER.info("getMenuItemListAdmin Service");	
		return menuItemRepository.findAll();
	}
	
	@Transactional
	public MenuItem getMenuItem(long menuItemId) {
		
		LOGGER.info("getMenuItem Service");		
		return menuItemRepository.findById(menuItemId).get();
	}
	
	@Transactional
	public void modifyMenuItem(MenuItem menuItem) {
		
		LOGGER.info("modifyMenuItem Service");		
		menuItemRepository.save(menuItem);
	}
}
