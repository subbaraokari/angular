package com.cognizant.truyum.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.security.AppUserDetailsService;
import com.cognizant.truyum.service.MenuItemService;


@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/menu-items") 
public class MenuItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);
	
	@Autowired
	MenuItemService menuItemService;
	
	@Autowired
	private AppUserDetailsService appUserDetailsService;
	
	
	@GetMapping("")
	public List<MenuItem> getAllMenuItems() {
		//return menuItemService.getMenuItemListCustomer();
		
		LOGGER.info("getAllMenuItems Controller...");
		
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		if(user.equalsIgnoreCase("anonymousUser")) {
			return this.menuItemService.getMenuItemListCustomer();
		} else {
			UserDetails userDetails = appUserDetailsService.loadUserByUsername(user);
			String role = userDetails.getAuthorities().toArray()[0].toString();
			if(role.equalsIgnoreCase("USER")) {
				return this.menuItemService.getMenuItemListCustomer();
			}
			else if(role.equalsIgnoreCase("ADMIN")) {
				return this.menuItemService.getMenuItemListAdmin();
			}
		}
		return null;
	}
	
	@GetMapping("/{id}")
	public MenuItem getMenuItem(@PathVariable long id) {
		
		LOGGER.info("getMenuItem Controller...");
		
		MenuItem item = new MenuItem();
		item = this.menuItemService.getMenuItem(id);
		return item;
	}
	
	@PutMapping()
	public void modifyMenuItem(@RequestBody MenuItem menuItem) {
		
		LOGGER.info("modifyMenuItem Controller...");
		menuItemService.modifyMenuItem(menuItem);
	}
}
