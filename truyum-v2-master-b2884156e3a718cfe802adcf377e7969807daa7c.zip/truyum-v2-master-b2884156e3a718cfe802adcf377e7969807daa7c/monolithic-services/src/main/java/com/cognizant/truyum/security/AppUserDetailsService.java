package com.cognizant.truyum.security;

import java.util.HashSet;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.exception.UserAlreadyExistsException;
import com.cognizant.truyum.model.Role;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.RoleRepository;
import com.cognizant.truyum.repository.UserRepository;

@Service
public class AppUserDetailsService implements UserDetailsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(AppUserDetailsService.class);
			
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	RoleRepository roleRepository;
	
	User user;
	AppUser appUser;
	
	public AppUserDetailsService() {
		super();
		LOGGER.info("AppUserDetailsService default constructor");
	}


	public AppUserDetailsService(UserRepository userRepository,RoleRepository roleRepository) {
		super();
		this.userRepository = userRepository;
		this.roleRepository = roleRepository;
		LOGGER.info("AppUserDetailsService parameterized constructor - 2 params");
	}


	public AppUserDetailsService(UserRepository userRepository2) {
		this.userRepository = userRepository2;
		LOGGER.info("AppUserDetailsService parameterized constructor - 1 params");
	}


	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		LOGGER.info("LoadUserByUserName Start");
		
        LOGGER.debug("UserRepository:{}", userRepository);
		user = userRepository.findByUsername(username);
		LOGGER.debug("User:{}", user);
		
		if(user == null) 
			throw new UsernameNotFoundException("UserName not found");
		else 
			appUser = new AppUser(user);
		
		LOGGER.info("LoadUserByUserName End");
		
		return appUser;
	}

	
	public void signUp(User newUser) throws UserAlreadyExistsException {
		LOGGER.info("AppUserDetailsService signUp start");
		
		User user = new User();
		user = userRepository.findByUsername(newUser.getUsername());
		if(user == null) {
			Role role = roleRepository.findById(2);
			String password = newUser.getPassword();
			Set<Role> roleList = new HashSet<Role>();
			roleList.add(role);
			newUser.setRoleList(roleList);

			
			newUser.setPassword(passwordEncoder().encode(password));
			userRepository.save(newUser);
		} else 
			throw new UserAlreadyExistsException();
		
		LOGGER.info("AppUserDetailsService signUp end");
	}
	
	public PasswordEncoder passwordEncoder() {
		LOGGER.info("password encoder");
		return new BCryptPasswordEncoder();
	}

}
