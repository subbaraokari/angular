package com.cognizant.truyum.exception;


@SuppressWarnings("serial")
public class UserAlreadyExistsException extends Exception {

	
	public UserAlreadyExistsException() {
		super();
	}

	public String getMessage() {
		return "User already exists";
	}
}
