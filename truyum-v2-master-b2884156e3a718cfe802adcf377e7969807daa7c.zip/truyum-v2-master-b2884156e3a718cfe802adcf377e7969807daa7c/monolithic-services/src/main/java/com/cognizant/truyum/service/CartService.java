package com.cognizant.truyum.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.truyum.dto.CartDTO;
import com.cognizant.truyum.exception.CartEmptyException;
import com.cognizant.truyum.model.MenuItem;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.MenuItemRepository;
import com.cognizant.truyum.repository.UserRepository;

@Service
public class CartService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartService.class);
			
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	MenuItemRepository menuItemRepository;
	
	@Transactional
	public void addCartItem(int userId, long menuItemId) {
		
		LOGGER.info("addCartItem Service...");
		
		User user = userRepository.findById(userId).get();
		MenuItem menuItem = menuItemRepository.findById(menuItemId).get();	
		List<MenuItem> menuItemList = user.getMenuItemList();
		menuItemList.add(menuItem);
		user.setMenuItemList(menuItemList);
		userRepository.save(user);
	}
		
	@Transactional
	public CartDTO getAllCartItems(int userId) throws CartEmptyException {
		
		LOGGER.info("getAllCartItems Service...");
		
		User user = userRepository.findById(userId).get();
		CartDTO cartDto = new CartDTO();
		cartDto.setMenuItemList(user.getMenuItemList());
		cartDto.setTotal(userRepository.getCartTotalPrice(userId));
		return cartDto;
	}
	
	public void removeCartItem(int userId, long menuItemId) {
		
		LOGGER.info("removeCartItem Service...");
		
		User user = userRepository.findById(userId).get();
		List<MenuItem> menuItemList = user.getMenuItemList();
		MenuItem menuItem = menuItemRepository.findById(menuItemId).get();		
		menuItemList.remove(menuItem);
		user.setMenuItemList(menuItemList);
		userRepository.save(user);
	}
}
