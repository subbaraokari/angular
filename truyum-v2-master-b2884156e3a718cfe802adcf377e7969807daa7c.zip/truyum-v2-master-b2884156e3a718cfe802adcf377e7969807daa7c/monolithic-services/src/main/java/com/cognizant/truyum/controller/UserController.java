package com.cognizant.truyum.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.truyum.exception.UserAlreadyExistsException;
import com.cognizant.truyum.model.User;
import com.cognizant.truyum.repository.UserRepository;
import com.cognizant.truyum.security.AppUserDetailsService;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping("/user")
public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	
	@Autowired
	AppUserDetailsService appUserDetailsService;	
	
	@Autowired
	private UserRepository userRepository;
	
	@GetMapping("/{username}")
	public User findByName(@PathVariable String username) {
		LOGGER.info("findByName controller...");
		return userRepository.findByUsername(username);
	}
	
	@GetMapping("")
	public List<User> getAllUsers() {
		LOGGER.info("getAllUsers controller...");
		return userRepository.findAll();
	}
	
	@PostMapping("")
	public void signUp(@RequestBody @Valid User user) throws UserAlreadyExistsException {
		LOGGER.info("signUp controller...");
		appUserDetailsService.signUp(user);
	}
	
	
	
//	@Autowired
//	private InMemoryUserDetailsManager inMemoryUserDetailsManager;
//	
//	public static List<UserDetails> userDetailsList = new ArrayList<>();
//	
//	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
//	
//	
//	public UserController() {
//		super();
//		
//		userDetailsList.add(
//				org.springframework.security.core.userdetails.User.withUsername("user")
//				.password(passwordEncoder().encode("pwd"))
//				.roles("USER").build());
//		
//		userDetailsList.add(
//				org.springframework.security.core.userdetails.User.withUsername("admin")
//				.password(passwordEncoder().encode("pwd"))
//				.roles("ADMIN").build());
//	}
//
//	@Bean
//	public PasswordEncoder passwordEncoder() {
//		return new BCryptPasswordEncoder();
//	}
//
//	@PostMapping("")
//	public void signUp(@RequestBody @Valid User user) {
//		Boolean details = inMemoryUserDetailsManager.userExists(user.getUsername());
//		if(details) {
//			try {
//				throw new UserAlreadyExistsException();
//			} catch (UserAlreadyExistsException e) {
//				throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
//			}
//		}
//		else {
//			inMemoryUserDetailsManager.createUser(
//					org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
//					.password(passwordEncoder().encode(user.getPassword())).roles("USER").build());
//			
//			userDetailsList.add(org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
//					.password(passwordEncoder().encode(user.getPassword())).roles("USER").build());
//			
//			LOGGER.debug(inMemoryUserDetailsManager.toString());		
//		}
//	}
}
