package com.cognizant.truyum.model;

import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Entity
@Table(name = "user")
public class User {


	private static final Logger LOGGER = LoggerFactory.getLogger(User.class);
			
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "us_id")
	private int userId;
	
	@Column(name = "us_name")
	@NotNull(message = "User Name is Required")
	private String username;
	
	//@Size(min = 2, max = 10, message = "Min len 2, Max len 10")
	@Column(name = "us_password")
	private String password;
	
	@Column(name = "us_first_name")
	private String firstname;
	
	@Column(name = "us_last_name")
	private String lastname;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "ur_us_id"), inverseJoinColumns = @JoinColumn(name = "ur_ro_id"))
	private Set<Role> roleList;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "cart", joinColumns = @JoinColumn(name = "ct_us_id"), inverseJoinColumns = @JoinColumn(name = "ct_me_id"))
	private List<MenuItem> menuItemList;
	
	public User() {
		super();
		LOGGER.info("User default constructor");
	}

	public User(int userId, @NotNull(message = "User Name is Required") String username,
			String password, String firstname, String lastname, Set<Role> roleList,
			List<MenuItem> menuItemList) {
		super();
		this.userId = userId;
		this.username = username;
		this.password = password;
		this.firstname = firstname;
		this.lastname = lastname;
		this.roleList = roleList;
		this.menuItemList = menuItemList;
		LOGGER.info("User parameterized Constructor - all");
	}

	public User(String username, String password, String firstname, String lastname) {
		// TODO Auto-generated constructor stub
		this.username =username;
		this.password = password;
		this.firstname = firstname;
		this.lastname = lastname;
		LOGGER.info("User parameterized constructor - 4 params");
	}

	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Set<Role> getRoleList() {
		return roleList;
	}


	public void setRoleList(Set<Role> roleList) {
		this.roleList = roleList;
	}

	
	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public List<MenuItem> getMenuItemList() {
		return menuItemList;
	}


	public void setMenuItemList(List<MenuItem> menuItemList) {
		this.menuItemList = menuItemList;
	}



	@Override
	public String toString() {
		return "User [userId=" + userId + ", username=" + username + ", password=" + password
				+ ", firstname=" + firstname + ", lastname=" + lastname + ", roleList=" + roleList
				+ ", menuItemList=" + menuItemList + "]";
	}

	
	
	
//	@NotNull(message = "User Name is Required")
//	private String username;
//	@Size(min = 2, max = 10, message = "Min len 2, Max len 10")
//	private String password;
//	private String confirmPassword;
//	@NotNull(message = "First Name is Required")
//	private String firstname;
//	@NotNull(message = "Last Name is Required")
//	private String lastname;
//	private String role;
//	
//	
//	public User() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//
//
//	public User(String username, String password, String confirmPassword, String firstname,
//			String lastname, String role) {
//		super();
//		this.username = username;
//		this.password = password;
//		this.confirmPassword = confirmPassword;
//		this.firstname = firstname;
//		this.lastname = lastname;
//		this.role = role;
//	}
//
//
//	public String getUsername() {
//		return username;
//	}
//
//
//	public void setUsername(String username) {
//		this.username = username;
//	}
//
//
//	public String getPassword() {
//		return password;
//	}
//
//
//	public void setPassword(String password) {
//		this.password = password;
//	}
//
//
//	public String getConfirmPassword() {
//		return confirmPassword;
//	}
//
//
//	public void setConfirmPassword(String confirmPassword) {
//		this.confirmPassword = confirmPassword;
//	}
//
//
//	public String getFirstname() {
//		return firstname;
//	}
//
//
//	public void setFirstname(String firstname) {
//		this.firstname = firstname;
//	}
//
//
//	public String getLastname() {
//		return lastname;
//	}
//
//
//	public void setLastname(String lastname) {
//		this.lastname = lastname;
//	}
//
//
//	public String getRole() {
//		return role;
//	}
//
//
//	public void setRole(String role) {
//		this.role = role;
//	}
//
//
//	@Override
//	public String toString() {
//		return "User [username=" + username + ", password=" + password + ", confirmPassword="
//				+ confirmPassword + ", firstname=" + firstname + ", lastname=" + lastname
//				+ ", role=" + role + "]";
//	}
//	
	


	


	
}
