INSERT INTO truyum_db.menu_item VALUES(1, 'Sandwich', 99.00, 1, '2017/03/15', 'Main Course', 1, 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af');
INSERT INTO truyum_db.menu_item VALUES(2, 'Burger', 129.00, 1, '2017/12/23', 'Main Course', 0, 'https://images.unsplash.com/photo-1512152272829-e3139592d56f');
INSERT INTO truyum_db.menu_item VALUES(3, 'Pizza', 149.00, 1, '2017/08/21', 'Main Course', 0, 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee');
INSERT INTO truyum_db.menu_item VALUES(4, 'French Fries', 57.00, 0, '2017/07/02', 'Starters', 1, 'https://images.unsplash.com/photo-1526230427044-d092040d48dc');
INSERT INTO truyum_db.menu_item VALUES(5, 'Chocolate Brownie', 32.00, 1, '2022/11/02', 'Dessert', 1, 'https://images.unsplash.com/photo-1564355808539-22fda35bed7e');


INSERT INTO truyum_db.user VALUES(1,'Scott','$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK', 'Scott', 'aaa');
INSERT INTO truyum_db.user VALUES(2,'Smith','$2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK', 'Smith', 'bbb');


INSERT INTO truyum_db.role VALUES(1,'ADMIN');
INSERT INTO truyum_db.role VALUES(2,'USER');


INSERT INTO truyum_db.user_role VALUES(1,1,1);
INSERT INTO truyum_db.user_role VALUES(2,2,2);